# KEYNOTE-789

Historical replay — not a prospective prediction.

[Open this exact record](https://8.148.145.28/arena?target=history-replay-case-007)

## Clinical trial

| Field | Recorded value |
| --- | --- |
| NCT | NCT03515837 |
| Drug | pembrolizumab |
| Sponsor | N/A |
| Indication | Stage IV nonsquamous NSCLC with EGFR DEL19 or L858R mutation and progression after EGFR-TKI; randomized N=492 |
| Phase | N/A |
| Study design | N/A |
| Trial status | N/A |
| Primary endpoint | OS and PFS in EGFR-mutant post-TKI metastatic nonsquamous NSCLC; pembrolizumab\+chemotherapy versus placebo\+chemotherapy |
| Population | Stage IV nonsquamous NSCLC with EGFR DEL19 or L858R mutation and progression after EGFR-TKI; randomized N=492 |
| Comparison | Pembrolizumab plus pemetrexed-platinum chemotherapy versus placebo plus same chemotherapy |
| Success definition | N/A |
| Information cutoff | 2023-01-02 |
| Expected readout / archived readout | 2023-02-28 |

## AI Clinical Trial Predictions

| Model / version | Outcome | Success probability | Confidence | Status | Record time UTC | Prediction vs reality |
| --- | --- | --- | --- | --- | --- | --- |
| deepseek-flash | Failure | N/A | N/A | predicted | 2026-10-17T07:36:18.179453\+00:00 | historical\_replay |
| deepseek-v4-pro | Failure | N/A | N/A | predicted | 2026-10-17T07:36:29.109802\+00:00 | historical\_replay |

These are actual stored records. Probability and confidence are not clinically calibrated. Refusals and failures remain in the assigned denominator.

## Consensus and actual result

Majority prediction: Failure.
Assigned model records: 2.
Actual result: failure; public date: 2023-02-28.
Historical source-curated research label, checked by AI agents; no independent human adjudication is claimed. Model execution followed public results. This is a retrospective replay, not a prospective hit.
Official result source: https://www.merck.com/news/merck-provides-update-on-phase-3-trials-keynote-641-and-keynote-789/
Historical replay does not earn prospective hits; no accuracy claim is made.

Public sources:
- KEYNOTE-789 original public result: https://www.merck.com/news/merck-provides-update-on-phase-3-trials-keynote-641-and-keynote-789/
- KEYNOTE-789 numeric result publication: https://doi.org/10.1200/jco.23.02747
- KEYNOTE-789 archived design data: https://aact.ctti-clinicaltrials.org/static/exported\_files/monthly/20230102\_pipe-delimited-export.zip
