# INAVO121

Current formal clinical question.

[Open this exact record](https://8.148.145.28/arena?target=of-season-20261023-corrected-inavo121)

## Clinical trial

| Field | Recorded value |
| --- | --- |
| NCT | NCT05646862 |
| Drug | inavolisib |
| Sponsor | Roche / Genentech |
| Indication | Post-CDK4/6 HR-positive breast cancer |
| Phase | PHASE3 |
| Study design | \{"allocation": "RANDOMIZED", "enrollment": \{"count": 420, "type": "ESTIMATED"\}, "intervention\_model": "PARALLEL", "masking": "NONE", "primary\_purpose": "TREATMENT"\} |
| Trial status | RECRUITING |
| Primary endpoint | Blinded Independent Central Review \(BICR\)-Assessed Progression Free Survival \(PFS\) |
| Population | HR-positive, HER2-negative, PIK3CA-mutated locally advanced/metastatic breast cancer progressing during or after CDK4/6 inhibitor plus endocrine therapy; main randomized study only. |
| Comparison | Inavolisib \+ fulvestrant versus alpelisib \+ fulvestrant. |
| Success definition | The first official decisive prespecified primary analysis of Blinded Independent Central Review \(BICR\)-Assessed Progression Free Survival \(PFS\) reports statistically qualifying superiority favoring the experimental regimen over the specified comparator in the specified analysis population, under the operative protocol/SAP including any interim and multiplicity rules. Success=1 only when that exact hypothesis qualifies; failure=0 only when an official decisive analysis states that exact primary criterion was not met \(including explicit target-specific futility\). Other populations/endpoints, nominal significance, non-target trial results, approval, silence, delay and commercial discontinuation without decisive endpoint assessment do not resolve the target. If SAP qualification or the exact analysis population remains unclear, outcome remains unresolved. |
| Information cutoff | 2026-10-22T17:00:02.856446\+00:00 |
| Expected readout / archived readout | 2026 sponsor guidance |

## AI Clinical Trial Predictions

| Model / version | Outcome | Success probability | Confidence | Status | Record time UTC | Prediction vs reality |
| --- | --- | --- | --- | --- | --- | --- |
| deepseek-v4-pro | Uncertain | N/A | N/A | abstained | 2026-10-22T17:07:23.872375\+00:00 | not\_evaluable |
| deepseek-v4.1-flash | Failure | N/A | N/A | predicted | 2026-10-22T17:07:31.633404\+00:00 | not\_evaluable |
| glm-5.2 | Uncertain | N/A | N/A | failed | 2026-10-22T17:09:18.916328\+00:00 | not\_evaluable |
| kimi-k3 | Uncertain | N/A | N/A | abstained | 2026-10-22T17:07:49.821092\+00:00 | not\_evaluable |

These are actual stored records. Probability and confidence are not clinically calibrated. Refusals and failures remain in the assigned denominator.

## Consensus and actual result

Majority prediction: Uncertain.
Assigned model records: 4.
Actual result: Awaiting results. No correctness score is available.

Public sources:
- INAVO121 frozen registered design: https://clinicaltrials.gov/api/v2/studies/NCT05646862
- Different-combination INAVO120 prior: https://assets.roche.com/f/176343/x/214d9ddfff/irp261022.pdf
