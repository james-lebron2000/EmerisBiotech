# EMBER-4

Current formal clinical question.

[Open this exact record](https://8.148.145.28/arena?target=of-season-20261023-corrected-ember4)

## Clinical trial

| Field | Recorded value |
| --- | --- |
| NCT | NCT05514054 |
| Drug | imlunestrant |
| Sponsor | Eli Lilly |
| Indication | Adjuvant ER-positive early breast cancer |
| Phase | PHASE3 |
| Study design | \{"allocation": "RANDOMIZED", "enrollment": \{"count": 8000, "type": "ESTIMATED"\}, "intervention\_model": "PARALLEL", "masking": "NONE", "primary\_purpose": "TREATMENT"\} |
| Trial status | ACTIVE\_NOT\_RECRUITING |
| Primary endpoint | Invasive Disease-Free Survival \(IDFS\) |
| Population | Resected ER-positive, HER2-negative early breast cancer at increased recurrence risk after 24-60 months adjuvant endocrine therapy; no distant metastases; randomized population. |
| Comparison | Imlunestrant versus investigator choice tamoxifen, anastrozole, letrozole or exemestane. |
| Success definition | The first official decisive prespecified primary analysis of IDFS excluding second non-breast primary invasive cancers reports statistically qualifying superiority favoring the experimental regimen over the specified comparator in the specified analysis population, under the operative protocol/SAP including any interim and multiplicity rules. Success=1 only when that exact hypothesis qualifies; failure=0 only when an official decisive analysis states that exact primary criterion was not met \(including explicit target-specific futility\). Other populations/endpoints, nominal significance, non-target trial results, approval, silence, delay and commercial discontinuation without decisive endpoint assessment do not resolve the target. If SAP qualification or the exact analysis population remains unclear, outcome remains unresolved. |
| Information cutoff | 2026-10-22T17:00:02.856446\+00:00 |
| Expected readout / archived readout | 2027 sponsor guidance |

## AI Clinical Trial Predictions

| Model / version | Outcome | Success probability | Confidence | Status | Record time UTC | Prediction vs reality |
| --- | --- | --- | --- | --- | --- | --- |
| deepseek-v4-pro | Uncertain | N/A | N/A | abstained | 2026-10-22T17:08:24.157602\+00:00 | not\_evaluable |
| deepseek-v4.1-flash | Failure | N/A | N/A | predicted | 2026-10-22T17:09:07.828774\+00:00 | not\_evaluable |
| glm-5.2 | Uncertain | N/A | N/A | failed | 2026-10-22T17:12:35.081100\+00:00 | not\_evaluable |
| kimi-k3 | Uncertain | N/A | N/A | abstained | 2026-10-22T17:09:26.811333\+00:00 | not\_evaluable |

These are actual stored records. Probability and confidence are not clinically calibrated. Refusals and failures remain in the assigned denominator.

## Consensus and actual result

Majority prediction: Uncertain.
Assigned model records: 4.
Actual result: Awaiting results. No correctness score is available.

Public sources:
- EMBER-4 frozen registered design: https://clinicaltrials.gov/api/v2/studies/NCT05514054
- Mixed monotherapy EMBER-3 evidence: https://investor.lilly.com/news-releases/news-release-details/lillys-imlunestrant-oral-serd-significantly-improved-progression
