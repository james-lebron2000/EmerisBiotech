# OCEAN

Current formal clinical question.

[Open this exact record](https://8.148.145.28/arena?target=of-season-20261023-corrected-ocean)

## Clinical trial

| Field | Recorded value |
| --- | --- |
| NCT | NCT05263934 |
| Drug | depemokimab |
| Sponsor | GSK |
| Indication | Relapsing/refractory EGPA |
| Phase | PHASE3 |
| Study design | \{"allocation": "RANDOMIZED", "enrollment": \{"count": 163, "type": "ACTUAL"\}, "intervention\_model": "PARALLEL", "masking": "QUADRUPLE", "primary\_purpose": "TREATMENT"\} |
| Trial status | ACTIVE\_NOT\_RECRUITING |
| Primary endpoint | Number of participants with remission \(Birmingham Vasculitis Activity Score \[BVAS\] =0 and a dose of oral corticosteroid \[OCS\] less than or equal to \[&lt;=\] 4 milligram \[mg\] per day\) |
| Population | Adults with relapsing or refractory eosinophilic granulomatosis with polyangiitis, on stable standard therapy including prednisone-equivalent 7.5-50 mg/day at baseline; randomized primary population. |
| Comparison | Depemokimab \+ placebo mepolizumab versus mepolizumab \+ placebo depemokimab, both with standard care. |
| Success definition | The first official decisive prespecified primary analysis reports that depemokimab meets the protocol/SAP non-inferiority criterion versus mepolizumab for remission \(BVAS=0 and oral corticosteroid &lt;=4 mg/day\) at BOTH Week 36 and Week 52, in the specified primary analysis population. The non-inferiority margin is not inferred here and must be documented for adjudication. Success=1 only when that exact hypothesis qualifies; failure=0 only when an official decisive analysis states that exact primary criterion was not met \(including explicit target-specific futility\). Other populations/endpoints, nominal significance, non-target trial results, approval, silence, delay and commercial discontinuation without decisive endpoint assessment do not resolve the target. If SAP qualification or the exact analysis population remains unclear, outcome remains unresolved. |
| Information cutoff | 2026-10-22T17:00:02.856446\+00:00 |
| Expected readout / archived readout | H2 2026 sponsor guidance |

## AI Clinical Trial Predictions

| Model / version | Outcome | Success probability | Confidence | Status | Record time UTC | Prediction vs reality |
| --- | --- | --- | --- | --- | --- | --- |
| deepseek-v4-pro | Uncertain | N/A | N/A | abstained | 2026-10-22T17:12:39.446814\+00:00 | not\_evaluable |
| deepseek-v4.1-flash | Uncertain | N/A | N/A | abstained | 2026-10-22T17:12:42.882437\+00:00 | not\_evaluable |
| glm-5.2 | Uncertain | N/A | N/A | abstained | 2026-10-22T17:18:31.573920\+00:00 | not\_evaluable |
| kimi-k3 | Uncertain | N/A | N/A | abstained | 2026-10-22T17:12:43.983998\+00:00 | not\_evaluable |

These are actual stored records. Probability and confidence are not clinically calibrated. Refusals and failures remain in the assigned denominator.

## Consensus and actual result

Majority prediction: Uncertain.
Assigned model records: 4.
Actual result: Awaiting results. No correctness score is available.

Public sources:
- OCEAN frozen registered design: https://clinicaltrials.gov/api/v2/studies/NCT05263934
- Indirect placebo-controlled asthma evidence: https://www.gsk.com/media/ymchlx2f/q3-2024-results-announcement.pdf
- Sponsor confirms non-inferiority design: https://www.gsk-studyregister.com/trials/217102
