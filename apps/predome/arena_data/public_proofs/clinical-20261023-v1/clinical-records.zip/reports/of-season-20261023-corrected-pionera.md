# pionERA

Current formal clinical question.

[Open this exact record](https://8.148.145.28/arena?target=of-season-20261023-corrected-pionera)

## Clinical trial

| Field | Recorded value |
| --- | --- |
| NCT | NCT06065748 |
| Drug | giredestrant |
| Sponsor | Roche / Genentech |
| Indication | Endocrine-resistant advanced breast cancer |
| Phase | PHASE3 |
| Study design | \{"allocation": "RANDOMIZED", "enrollment": \{"count": 1050, "type": "ESTIMATED"\}, "intervention\_model": "PARALLEL", "masking": "NONE", "primary\_purpose": "TREATMENT"\} |
| Trial status | ACTIVE\_NOT\_RECRUITING |
| Primary endpoint | Progression-Free Survival \(PFS\) in the ESR1 mutation \(ESR1m\) Subgroup |
| Population | ER-positive, HER2-negative advanced breast cancer resistant to adjuvant endocrine therapy; selected primary analysis is the ESR1-mutated population, not the full analysis population coprimary endpoint. |
| Comparison | Giredestrant \+ investigator choice CDK4/6 inhibitor versus fulvestrant \+ investigator choice CDK4/6 inhibitor. |
| Success definition | The first official decisive prespecified primary analysis of investigator-assessed PFS in ESR1-mutated participants reports statistically qualifying superiority favoring the experimental regimen over the specified comparator in the specified analysis population, under the operative protocol/SAP including any interim and multiplicity rules. Success=1 only when that exact hypothesis qualifies; failure=0 only when an official decisive analysis states that exact primary criterion was not met \(including explicit target-specific futility\). Other populations/endpoints, nominal significance, non-target trial results, approval, silence, delay and commercial discontinuation without decisive endpoint assessment do not resolve the target. If SAP qualification or the exact analysis population remains unclear, outcome remains unresolved. |
| Information cutoff | 2026-10-22T17:00:02.856446\+00:00 |
| Expected readout / archived readout | 2027 sponsor guidance |

## AI Clinical Trial Predictions

| Model / version | Outcome | Success probability | Confidence | Status | Record time UTC | Prediction vs reality |
| --- | --- | --- | --- | --- | --- | --- |
| deepseek-v4-pro | Success | N/A | N/A | predicted | 2026-10-22T17:09:31.383805\+00:00 | not\_evaluable |
| deepseek-v4.1-flash | Failure | N/A | N/A | predicted | 2026-10-22T17:09:51.146904\+00:00 | not\_evaluable |
| glm-5.2 | Uncertain | N/A | N/A | failed | 2026-10-22T17:12:35.472650\+00:00 | not\_evaluable |
| kimi-k3 | Uncertain | N/A | N/A | failed | 2026-10-22T17:09:53.825932\+00:00 | not\_evaluable |

These are actual stored records. Probability and confidence are not clinically calibrated. Refusals and failures remain in the assigned denominator.

## Consensus and actual result

Majority prediction: Uncertain.
Assigned model records: 4.
Actual result: Awaiting results. No correctness score is available.

Public sources:
- pionERA frozen registered design: https://clinicaltrials.gov/api/v2/studies/NCT06065748
- Negative same-asset first-line prior: https://www.roche.com/media/releases/med-cor-2026-03-09
- Positive same-asset but different combination prior: https://www.roche.com/media/releases/med-cor-2026-10-01
