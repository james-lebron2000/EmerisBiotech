# CAMBRIA-1

Current formal clinical question.

[Open this exact record](https://8.148.145.28/arena?target=of-season-20261023-corrected-cambria1)

## Clinical trial

| Field | Recorded value |
| --- | --- |
| NCT | NCT05774951 |
| Drug | camizestrant |
| Sponsor | AstraZeneca |
| Indication | Adjuvant ER-positive early breast cancer |
| Phase | PHASE3 |
| Study design | \{"allocation": "RANDOMIZED", "enrollment": \{"count": 4300, "type": "ESTIMATED"\}, "intervention\_model": "PARALLEL", "masking": "NONE", "primary\_purpose": "TREATMENT"\} |
| Trial status | RECRUITING |
| Primary endpoint | Invasive breast cancer-free survival \(IBCFS\) |
| Population | Adults with resected ER-positive, HER2-negative early invasive breast cancer at intermediate/high recurrence risk, completed 2-5 years \(\+3 months\) adjuvant endocrine therapy, ECOG &lt;=1; randomized population. |
| Comparison | Camizestrant versus continued standard endocrine therapy \(aromatase inhibitor or tamoxifen\). |
| Success definition | The first official decisive prespecified primary analysis of invasive breast cancer-free survival reports statistically qualifying superiority favoring the experimental regimen over the specified comparator in the specified analysis population, under the operative protocol/SAP including any interim and multiplicity rules. Success=1 only when that exact hypothesis qualifies; failure=0 only when an official decisive analysis states that exact primary criterion was not met \(including explicit target-specific futility\). Other populations/endpoints, nominal significance, non-target trial results, approval, silence, delay and commercial discontinuation without decisive endpoint assessment do not resolve the target. If SAP qualification or the exact analysis population remains unclear, outcome remains unresolved. |
| Information cutoff | 2026-10-22T17:00:02.856446\+00:00 |
| Expected readout / archived readout | 2027 sponsor guidance |

## AI Clinical Trial Predictions

| Model / version | Outcome | Success probability | Confidence | Status | Record time UTC | Prediction vs reality |
| --- | --- | --- | --- | --- | --- | --- |
| deepseek-v4-pro | Uncertain | N/A | N/A | abstained | 2026-10-22T17:11:23.769473\+00:00 | not\_evaluable |
| deepseek-v4.1-flash | Failure | N/A | N/A | predicted | 2026-10-22T17:11:09.161952\+00:00 | not\_evaluable |
| glm-5.2 | Failure | N/A | N/A | predicted | 2026-10-22T17:16:01.058075\+00:00 | not\_evaluable |
| kimi-k3 | Uncertain | N/A | N/A | failed | 2026-10-22T17:11:55.540972\+00:00 | not\_evaluable |

These are actual stored records. Probability and confidence are not clinically calibrated. Refusals and failures remain in the assigned denominator.

## Consensus and actual result

Majority prediction: Uncertain.
Assigned model records: 4.
Actual result: Awaiting results. No correctness score is available.

Public sources:
- CAMBRIA-1 frozen registered design: https://clinicaltrials.gov/api/v2/studies/NCT05774951
- Negative metastatic PFS prior and distinct positive subgroup setting: https://www.astrazeneca.com/media-centre/press-releases/2026/update-serena-4-phase-iii-trial.html
