# evolutionRMS-2

Historical replay — not a prospective prediction.

[Open this exact record](https://8.148.145.28/arena?target=history-replay-case-003)

## Clinical trial

| Field | Recorded value |
| --- | --- |
| NCT | NCT04338061 |
| Drug | evobrutinib |
| Sponsor | N/A |
| Indication | Relapsing multiple sclerosis, age 18-55, EDSS 0.0-5.5; full analysis set |
| Phase | N/A |
| Study design | N/A |
| Trial status | N/A |
| Primary endpoint | Annualized relapse rate; evobrutinib versus teriflunomide |
| Population | Relapsing multiple sclerosis, age 18-55, EDSS 0.0-5.5; full analysis set |
| Comparison | Evobrutinib 45 mg twice daily versus teriflunomide 14 mg daily |
| Success definition | N/A |
| Information cutoff | 2023-01-02 |
| Expected readout / archived readout | 2023-12-05 |

## AI Clinical Trial Predictions

| Model / version | Outcome | Success probability | Confidence | Status | Record time UTC | Prediction vs reality |
| --- | --- | --- | --- | --- | --- | --- |
| deepseek-flash | Failure | N/A | N/A | predicted | 2026-10-17T07:36:18.179453\+00:00 | historical\_replay |
| deepseek-v4-pro | Failure | N/A | N/A | predicted | 2026-10-17T07:36:29.109802\+00:00 | historical\_replay |

These are actual stored records. Probability and confidence are not clinically calibrated. Refusals and failures remain in the assigned denominator.

## Consensus and actual result

Majority prediction: Failure.
Assigned model records: 2.
Actual result: failure; public date: 2023-12-05.
Historical source-curated research label, checked by AI agents; no independent human adjudication is claimed. Model execution followed public results. This is a retrospective replay, not a prospective hit.
Official result source: https://www.emdgroup.com/press-releases/2023/dec/us/Evobrutinib-phase-III-NA.pdf
Historical replay does not earn prospective hits; no accuracy claim is made.

Public sources:
- evolutionRMS-2 original public result: https://www.emdgroup.com/press-releases/2023/dec/us/Evobrutinib-phase-III-NA.pdf
- evolutionRMS-2 numeric result publication: https://doi.org/10.1016/s1474-4422\(24\)00328-4
- evolutionRMS-2 archived design data: https://aact.ctti-clinicaltrials.org/static/exported\_files/monthly/20230102\_pipe-delimited-export.zip
