# VITALIZE

Current formal clinical question.

[Open this exact record](https://8.148.145.28/arena?target=of-season-20261023-corrected-vitalize)

## Clinical trial

| Field | Recorded value |
| --- | --- |
| NCT | NCT06290141 |
| Drug | riliprubart |
| Sponsor | Sanofi |
| Indication | IVIg-treated CIDP |
| Phase | PHASE3 |
| Study design | \{"allocation": "RANDOMIZED", "enrollment": \{"count": 160, "type": "ESTIMATED"\}, "intervention\_model": "PARALLEL", "masking": "QUADRUPLE", "primary\_purpose": "TREATMENT"\} |
| Trial status | RECRUITING |
| Primary endpoint | Percentage of participants experiencing a response |
| Population | Adults with CIDP/eligible variants, prior IVIg response, stable maintenance IVIg, residual INCAT disability 2-9 and active disease; randomized Part A population. |
| Comparison | Riliprubart \+ placebo IVIg versus maintenance IVIg \+ placebo riliprubart over 24 weeks. |
| Success definition | The first official decisive prespecified primary analysis of Week-24 Part-A adjusted INCAT response \(at least 1-point decrease\) reports statistically qualifying superiority favoring the experimental regimen over the specified comparator in the specified analysis population, under the operative protocol/SAP including any interim and multiplicity rules. Success=1 only when that exact hypothesis qualifies; failure=0 only when an official decisive analysis states that exact primary criterion was not met \(including explicit target-specific futility\). Other populations/endpoints, nominal significance, non-target trial results, approval, silence, delay and commercial discontinuation without decisive endpoint assessment do not resolve the target. If SAP qualification or the exact analysis population remains unclear, outcome remains unresolved. |
| Information cutoff | 2026-10-22T17:00:02.856446\+00:00 |
| Expected readout / archived readout | 2027 CIDP药物项目指引；非VITALIZE专属承诺日期 |

## AI Clinical Trial Predictions

| Model / version | Outcome | Success probability | Confidence | Status | Record time UTC | Prediction vs reality |
| --- | --- | --- | --- | --- | --- | --- |
| deepseek-v4-pro | Failure | N/A | N/A | predicted | 2026-10-22T17:12:16.511067\+00:00 | not\_evaluable |
| deepseek-v4.1-flash | Failure | N/A | N/A | predicted | 2026-10-22T17:11:52.230967\+00:00 | not\_evaluable |
| glm-5.2 | Uncertain | N/A | N/A | failed | 2026-10-22T17:17:48.944714\+00:00 | not\_evaluable |
| kimi-k3 | Failure | N/A | N/A | predicted | 2026-10-22T17:12:24.084071\+00:00 | not\_evaluable |

These are actual stored records. Probability and confidence are not clinically calibrated. Refusals and failures remain in the assigned denominator.

## Consensus and actual result

Majority prediction: Failure.
Assigned model records: 4.
Actual result: Awaiting results. No correctness score is available.

Public sources:
- VITALIZE frozen registered design: https://clinicaltrials.gov/api/v2/studies/NCT06290141
- Negative riliprubart prior in a different CIDP population: https://www.sec.gov/Archives/edgar/data/1121404/000112140426000008/pressreleaseq22026english.htm
- Indirect open-label riliprubart CIDP week-24 evidence: https://www.sanofi.com/en/media-room/press-releases/2024/2024-06-25-20-30-00-2904145
- Conditional open-label riliprubart CIDP week-76 evidence: https://www.sanofi.com/assets/dotcom/content-app/events/investor-presentation/2025/2025-year-end-late-stage-pipeline-review/2025\_12\_16\_Sanofi\_Year-end\_late-stage\_pipeline\_review\_Pres.pdf
