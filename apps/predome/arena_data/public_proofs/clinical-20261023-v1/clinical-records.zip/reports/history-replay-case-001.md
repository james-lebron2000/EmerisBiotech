# SERENA-6

Historical replay — not a prospective prediction.

[Open this exact record](https://8.148.145.28/arena?target=history-replay-case-001)

## Clinical trial

| Field | Recorded value |
| --- | --- |
| NCT | NCT04964934 |
| Drug | camizestrant |
| Sponsor | N/A |
| Indication | ER-positive/HER2-negative advanced breast cancer with emergent ctDNA ESR1 mutation, at least 6 months first-line AI plus CDK4/6 inhibitor, no radiologic progression; randomized N=315 |
| Phase | N/A |
| Study design | N/A |
| Trial status | N/A |
| Primary endpoint | PFS after emergent ESR1 mutation before radiographic progression; switch to camizestrant versus continue AI, same CDK4/6 inhibitor |
| Population | ER-positive/HER2-negative advanced breast cancer with emergent ctDNA ESR1 mutation, at least 6 months first-line AI plus CDK4/6 inhibitor, no radiologic progression; randomized N=315 |
| Comparison | Switch to camizestrant plus same CDK4/6 inhibitor versus continue AI plus same CDK4/6 inhibitor |
| Success definition | N/A |
| Information cutoff | 2023-01-02 |
| Expected readout / archived readout | 2025-02-26 |

## AI Clinical Trial Predictions

| Model / version | Outcome | Success probability | Confidence | Status | Record time UTC | Prediction vs reality |
| --- | --- | --- | --- | --- | --- | --- |
| deepseek-flash | Success | N/A | N/A | predicted | 2026-10-17T07:36:18.179453\+00:00 | historical\_replay |
| deepseek-v4-pro | Failure | N/A | N/A | predicted | 2026-10-17T07:36:29.109802\+00:00 | historical\_replay |

These are actual stored records. Probability and confidence are not clinically calibrated. Refusals and failures remain in the assigned denominator.

## Consensus and actual result

Majority prediction: Uncertain.
Assigned model records: 2.
Actual result: success; public date: 2025-02-26.
Historical source-curated research label, checked by AI agents; no independent human adjudication is claimed. Model execution followed public results. This is a retrospective replay, not a prospective hit.
Official result source: https://www.astrazeneca.com/media-centre/press-releases/2025/camizestrant-improved-pfs-in-1l-hr-breast-cancer.html
Historical replay does not earn prospective hits; no accuracy claim is made.

Public sources:
- SERENA-6 original public result: https://www.astrazeneca.com/media-centre/press-releases/2025/camizestrant-improved-pfs-in-1l-hr-breast-cancer.html
- SERENA-6 numeric result publication: https://doi.org/10.1056/nejmoa2502929
- SERENA-6 archived design data: https://aact.ctti-clinicaltrials.org/static/exported\_files/monthly/20230102\_pipe-delimited-export.zip
