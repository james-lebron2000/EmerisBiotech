# MEVPRO-1

Current formal clinical question.

[Open this exact record](https://8.148.145.28/arena?target=of-season-20261023-corrected-mevpro1)

## Clinical trial

| Field | Recorded value |
| --- | --- |
| NCT | NCT06551324 |
| Drug | mevrometostat |
| Sponsor | Pfizer |
| Indication | Metastatic castration-resistant prostate cancer |
| Phase | PHASE3 |
| Study design | \{"allocation": "RANDOMIZED", "enrollment": \{"count": 600, "type": "ESTIMATED"\}, "intervention\_model": "PARALLEL", "masking": "NONE", "primary\_purpose": "TREATMENT"\} |
| Trial status | ACTIVE\_NOT\_RECRUITING |
| Primary endpoint | Radiographic Progression Free Survival \(rPFS\) assessed by blinded independent central review \(BICR\) per RECIST v1.1 and Prostate Cancer Clinical Trials Working Group 3 \(PCWG3\) |
| Population | Metastatic castration-resistant prostate adenocarcinoma progressing after abiraterone in mCSPC or first-line mCRPC; ECOG 0-2; randomized analysis population. |
| Comparison | Mevrometostat 875 mg twice daily with food \+ enzalutamide 160 mg/day versus physician choice enzalutamide or docetaxel. |
| Success definition | The first official decisive prespecified primary analysis of Radiographic Progression Free Survival \(rPFS\) assessed by blinded independent central review \(BICR\) per RECIST v1.1 and Prostate Cancer Clinical Trials Working Group 3 \(PCWG3\) reports statistically qualifying superiority favoring the experimental regimen over the specified comparator in the specified analysis population, under the operative protocol/SAP including any interim and multiplicity rules. Success=1 only when that exact hypothesis qualifies; failure=0 only when an official decisive analysis states that exact primary criterion was not met \(including explicit target-specific futility\). Other populations/endpoints, nominal significance, non-target trial results, approval, silence, delay and commercial discontinuation without decisive endpoint assessment do not resolve the target. If SAP qualification or the exact analysis population remains unclear, outcome remains unresolved. |
| Information cutoff | 2026-10-22T17:00:02.856446\+00:00 |
| Expected readout / archived readout | 2026 sponsor guidance |

## AI Clinical Trial Predictions

| Model / version | Outcome | Success probability | Confidence | Status | Record time UTC | Prediction vs reality |
| --- | --- | --- | --- | --- | --- | --- |
| deepseek-v4-pro | Uncertain | N/A | N/A | abstained | 2026-10-22T17:07:36.419856\+00:00 | not\_evaluable |
| deepseek-v4.1-flash | Failure | N/A | N/A | predicted | 2026-10-22T17:08:00.434361\+00:00 | not\_evaluable |
| glm-5.2 | Uncertain | N/A | N/A | failed | 2026-10-22T17:10:27.332370\+00:00 | not\_evaluable |
| kimi-k3 | Success | N/A | N/A | predicted | 2026-10-22T17:08:26.061038\+00:00 | not\_evaluable |

These are actual stored records. Probability and confidence are not clinically calibrated. Refusals and failures remain in the assigned denominator.

## Consensus and actual result

Majority prediction: Uncertain.
Assigned model records: 4.
Actual result: Awaiting results. No correctness score is available.

Public sources:
- MEVPRO-1 frozen registered design: https://clinicaltrials.gov/api/v2/studies/NCT06551324
- Published protocol and phase I background: https://pmc.ncbi.nlm.nih.gov/articles/PMC13203012/
