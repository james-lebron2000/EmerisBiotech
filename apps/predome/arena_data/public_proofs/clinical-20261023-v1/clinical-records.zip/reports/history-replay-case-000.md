# INAVO120

Historical replay — not a prospective prediction.

[Open this exact record](https://8.148.145.28/arena?target=history-replay-case-000)

## Clinical trial

| Field | Recorded value |
| --- | --- |
| NCT | NCT04191499 |
| Drug | inavolisib |
| Sponsor | N/A |
| Indication | PIK3CA-mutated HR-positive/HER2-negative locally advanced or metastatic breast cancer relapsing during or within 12 months of adjuvant endocrine therapy; first-line advanced setting; randomized N=325 |
| Phase | N/A |
| Study design | N/A |
| Trial status | N/A |
| Primary endpoint | PFS in PIK3CA-mutant HR\+ HER2- endocrine-resistant advanced breast cancer; inavolisib\+palbociclib\+fulvestrant versus placebo\+palbociclib\+fulvestrant |
| Population | PIK3CA-mutated HR-positive/HER2-negative locally advanced or metastatic breast cancer relapsing during or within 12 months of adjuvant endocrine therapy; first-line advanced setting; randomized N=325 |
| Comparison | Inavolisib plus palbociclib-fulvestrant versus placebo plus palbociclib-fulvestrant |
| Success definition | N/A |
| Information cutoff | 2023-01-02 |
| Expected readout / archived readout | 2023-12-05 |

## AI Clinical Trial Predictions

| Model / version | Outcome | Success probability | Confidence | Status | Record time UTC | Prediction vs reality |
| --- | --- | --- | --- | --- | --- | --- |
| deepseek-flash | Uncertain | N/A | N/A | abstained | 2026-10-17T07:36:18.179453\+00:00 | historical\_replay |
| deepseek-v4-pro | Uncertain | N/A | N/A | abstained | 2026-10-17T07:36:29.109802\+00:00 | historical\_replay |

These are actual stored records. Probability and confidence are not clinically calibrated. Refusals and failures remain in the assigned denominator.

## Consensus and actual result

Majority prediction: Uncertain.
Assigned model records: 2.
Actual result: success; public date: 2023-12-05.
Historical source-curated research label, checked by AI agents; no independent human adjudication is claimed. Model execution followed public results. This is a retrospective replay, not a prospective hit.
Official result source: https://www.roche.com/media/releases/med-cor-2023-12-05
Historical replay does not earn prospective hits; no accuracy claim is made.

Public sources:
- INAVO120 original public result: https://www.roche.com/media/releases/med-cor-2023-12-05
- INAVO120 numeric result publication: https://doi.org/10.1056/nejmoa2404625
- INAVO120 archived design data: https://aact.ctti-clinicaltrials.org/static/exported\_files/monthly/20230102\_pipe-delimited-export.zip
