# AVANZAR

Current formal clinical question.

[Open this exact record](https://8.148.145.28/arena?target=of-season-20261023-corrected-avanzar)

## Clinical trial

| Field | Recorded value |
| --- | --- |
| NCT | NCT05687266 |
| Drug | datopotamab deruxtecan |
| Sponsor | AstraZeneca / Daiichi Sankyo |
| Indication | First-line advanced NSCLC |
| Phase | PHASE3 |
| Study design | \{"allocation": "RANDOMIZED", "enrollment": \{"count": 1350, "type": "ACTUAL"\}, "intervention\_model": "PARALLEL", "masking": "NONE", "primary\_purpose": "TREATMENT"\} |
| Trial status | ACTIVE\_NOT\_RECRUITING |
| Primary endpoint | Progression-Free Survival \(PFS\) by blinded independent central review \(BICR\) in the non-squamous TROP2 biomarker positive population |
| Population | Previously untreated advanced non-squamous NSCLC without actionable genomic alterations; analysis restricted to TROP2 biomarker-positive non-squamous patients. |
| Comparison | Dato-DXd 6 mg/kg \+ durvalumab \+ carboplatin versus pembrolizumab \+ pemetrexed \+ platinum chemotherapy. |
| Success definition | The first official decisive prespecified primary analysis of BICR PFS in non-squamous TROP2-positive patients reports statistically qualifying superiority favoring the experimental regimen over the specified comparator in the specified analysis population, under the operative protocol/SAP including any interim and multiplicity rules. Success=1 only when that exact hypothesis qualifies; failure=0 only when an official decisive analysis states that exact primary criterion was not met \(including explicit target-specific futility\). Other populations/endpoints, nominal significance, non-target trial results, approval, silence, delay and commercial discontinuation without decisive endpoint assessment do not resolve the target. If SAP qualification or the exact analysis population remains unclear, outcome remains unresolved. |
| Information cutoff | 2026-10-22T17:00:02.856446\+00:00 |
| Expected readout / archived readout | H2 2026 sponsor guidance |

## AI Clinical Trial Predictions

| Model / version | Outcome | Success probability | Confidence | Status | Record time UTC | Prediction vs reality |
| --- | --- | --- | --- | --- | --- | --- |
| deepseek-v4-pro | Uncertain | N/A | N/A | abstained | 2026-10-22T17:06:58.759881\+00:00 | not\_evaluable |
| deepseek-v4.1-flash | Failure | N/A | N/A | predicted | 2026-10-22T17:06:37.672527\+00:00 | not\_evaluable |
| glm-5.2 | Uncertain | N/A | N/A | failed | 2026-10-22T17:07:19.701820\+00:00 | not\_evaluable |
| kimi-k3 | Failure | N/A | N/A | predicted | 2026-10-22T17:07:13.963365\+00:00 | not\_evaluable |

These are actual stored records. Probability and confidence are not clinically calibrated. Refusals and failures remain in the assigned denominator.

## Consensus and actual result

Majority prediction: Uncertain.
Assigned model records: 4.
Actual result: Awaiting results. No correctness score is available.

Public sources:
- AVANZAR frozen registered design: https://clinicaltrials.gov/api/v2/studies/NCT05687266
- Corrected indirect randomized Dato evidence: https://www.ebi.ac.uk/europepmc/webservices/rest/PMC11771353/fullTextXML
- Indirect first-line combination response evidence: https://www.astrazeneca.com/media-centre/press-releases/2023/datopotamab-deruxtecan-plus-imfinzi-showed-promising-clinical-activity-in-the-first-line-advanced-non-small-cell-lung-cancer-setting.html
