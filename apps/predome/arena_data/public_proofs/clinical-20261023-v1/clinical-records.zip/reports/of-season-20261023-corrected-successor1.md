# SUCCESSOR-1

Current formal clinical question.

[Open this exact record](https://8.148.145.28/arena?target=of-season-20261023-corrected-successor1)

## Clinical trial

| Field | Recorded value |
| --- | --- |
| NCT | NCT05519085 |
| Drug | mezigdomide |
| Sponsor | Bristol Myers Squibb / Celgene |
| Indication | Relapsed/refractory multiple myeloma |
| Phase | PHASE3 |
| Study design | \{"allocation": "RANDOMIZED", "enrollment": \{"count": 810, "type": "ESTIMATED"\}, "intervention\_model": "PARALLEL", "masking": "NONE", "primary\_purpose": "TREATMENT"\} |
| Trial status | RECRUITING |
| Primary endpoint | Progression-free Survival \(PFS\) |
| Population | Relapsed/refractory multiple myeloma with 1-3 prior lines and at least minimal response to a previous therapy; excludes prior pomalidomide/mezigdomide and specified proteasome-inhibitor refractory disease. Target is the confirmatory selected-dose randomized phase III comparison. |
| Comparison | Selected confirmatory mezigdomide 1.0 mg \+ bortezomib/dexamethasone versus pomalidomide \+ bortezomib/dexamethasone. |
| Success definition | The first official decisive prespecified primary analysis of confirmatory selected-dose phase III randomized PFS reports statistically qualifying superiority favoring the experimental regimen over the specified comparator in the specified analysis population, under the operative protocol/SAP including any interim and multiplicity rules. Success=1 only when that exact hypothesis qualifies; failure=0 only when an official decisive analysis states that exact primary criterion was not met \(including explicit target-specific futility\). Other populations/endpoints, nominal significance, non-target trial results, approval, silence, delay and commercial discontinuation without decisive endpoint assessment do not resolve the target. If SAP qualification or the exact analysis population remains unclear, outcome remains unresolved. |
| Information cutoff | 2026-10-22T17:00:02.856446\+00:00 |
| Expected readout / archived readout | 2027 sponsor guidance |

## AI Clinical Trial Predictions

| Model / version | Outcome | Success probability | Confidence | Status | Record time UTC | Prediction vs reality |
| --- | --- | --- | --- | --- | --- | --- |
| deepseek-v4-pro | Uncertain | N/A | N/A | abstained | 2026-10-22T17:10:17.223152\+00:00 | not\_evaluable |
| deepseek-v4.1-flash | Success | N/A | N/A | predicted | 2026-10-22T17:10:17.786008\+00:00 | not\_evaluable |
| glm-5.2 | Failure | N/A | N/A | predicted | 2026-10-22T17:13:05.753113\+00:00 | not\_evaluable |
| kimi-k3 | Success | N/A | N/A | predicted | 2026-10-22T17:10:21.213275\+00:00 | not\_evaluable |

These are actual stored records. Probability and confidence are not clinically calibrated. Refusals and failures remain in the assigned denominator.

## Consensus and actual result

Majority prediction: Uncertain.
Assigned model records: 4.
Actual result: Awaiting results. No correctness score is available.

Public sources:
- SUCCESSOR-1 frozen registered design: https://clinicaltrials.gov/api/v2/studies/NCT05519085
- Positive mezigdomide with a different backbone: https://news.bms.com/news/corporate-financial/2026/Bristol-Myers-Squibb-Announces-CELMoD-Mezigdomide-Reduces-Risk-of-Disease-Progression-or-Death-by-More-than-50-vs--Standard-of-Care-in-Relapsed-or-Refractory-Multiple-Myeloma/default.aspx
