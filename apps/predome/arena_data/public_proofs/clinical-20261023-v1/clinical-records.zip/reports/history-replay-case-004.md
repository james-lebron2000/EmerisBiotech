# HERCULES

Historical replay — not a prospective prediction.

[Open this exact record](https://8.148.145.28/arena?target=history-replay-case-004)

## Clinical trial

| Field | Recorded value |
| --- | --- |
| NCT | NCT04411641 |
| Drug | tolebrutinib |
| Sponsor | N/A |
| Indication | Nonrelapsing secondary progressive multiple sclerosis; randomized N=1131 |
| Phase | N/A |
| Study design | N/A |
| Trial status | N/A |
| Primary endpoint | Time to 6month confirmed disability progression in nonrelapsing secondary progressive MS; tolebrutinib versus placebo |
| Population | Nonrelapsing secondary progressive multiple sclerosis; randomized N=1131 |
| Comparison | Tolebrutinib 60 mg daily versus placebo |
| Success definition | N/A |
| Information cutoff | 2023-01-02 |
| Expected readout / archived readout | 2024-09-02 |

## AI Clinical Trial Predictions

| Model / version | Outcome | Success probability | Confidence | Status | Record time UTC | Prediction vs reality |
| --- | --- | --- | --- | --- | --- | --- |
| deepseek-flash | Uncertain | N/A | N/A | abstained | 2026-10-17T07:36:18.179453\+00:00 | historical\_replay |
| deepseek-v4-pro | Uncertain | N/A | N/A | abstained | 2026-10-17T07:36:29.109802\+00:00 | historical\_replay |

These are actual stored records. Probability and confidence are not clinically calibrated. Refusals and failures remain in the assigned denominator.

## Consensus and actual result

Majority prediction: Uncertain.
Assigned model records: 2.
Actual result: success; public date: 2024-09-02.
Historical source-curated research label, checked by AI agents; no independent human adjudication is claimed. Model execution followed public results. This is a retrospective replay, not a prospective hit.
Official result source: https://www.sanofi.com/assets/dotcom/pressreleases/2024/2024-09-02-05-00-00-2938875-en.pdf
Historical replay does not earn prospective hits; no accuracy claim is made.

Public sources:
- HERCULES original public result: https://www.sanofi.com/assets/dotcom/pressreleases/2024/2024-09-02-05-00-00-2938875-en.pdf
- HERCULES numeric result publication: https://doi.org/10.1056/nejmoa2415988
- HERCULES archived design data: https://aact.ctti-clinicaltrials.org/static/exported\_files/monthly/20230102\_pipe-delimited-export.zip
