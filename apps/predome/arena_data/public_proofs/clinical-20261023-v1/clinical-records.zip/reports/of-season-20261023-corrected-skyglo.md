# SKYGLO

Current formal clinical question.

[Open this exact record](https://8.148.145.28/arena?target=of-season-20261023-corrected-skyglo)

## Clinical trial

| Field | Recorded value |
| --- | --- |
| NCT | NCT06047080 |
| Drug | glofitamab |
| Sponsor | Roche / Genentech |
| Indication | Previously untreated large B-cell lymphoma |
| Phase | PHASE3 |
| Study design | \{"allocation": "RANDOMIZED", "enrollment": \{"count": 1130, "type": "ACTUAL"\}, "intervention\_model": "PARALLEL", "masking": "NONE", "primary\_purpose": "TREATMENT"\} |
| Trial status | ACTIVE\_NOT\_RECRUITING |
| Primary endpoint | Progression-free survival \(PFS\) as determined by Independent Review Facility \(IRF\) |
| Population | Previously untreated CD20-positive large B-cell lymphoma meeting protocol eligibility, IPI 2-5, ECOG 0-2; randomized population. |
| Comparison | Glofitamab \+ polatuzumab vedotin \+ rituximab/cyclophosphamide/doxorubicin/prednisone \(Pola-R-CHP\) versus Pola-R-CHP. |
| Success definition | The first official decisive prespecified primary analysis of Progression-free survival \(PFS\) as determined by Independent Review Facility \(IRF\) reports statistically qualifying superiority favoring the experimental regimen over the specified comparator in the specified analysis population, under the operative protocol/SAP including any interim and multiplicity rules. Success=1 only when that exact hypothesis qualifies; failure=0 only when an official decisive analysis states that exact primary criterion was not met \(including explicit target-specific futility\). Other populations/endpoints, nominal significance, non-target trial results, approval, silence, delay and commercial discontinuation without decisive endpoint assessment do not resolve the target. If SAP qualification or the exact analysis population remains unclear, outcome remains unresolved. |
| Information cutoff | 2026-10-22T17:00:02.856446\+00:00 |
| Expected readout / archived readout | 2027 sponsor guidance |

## AI Clinical Trial Predictions

| Model / version | Outcome | Success probability | Confidence | Status | Record time UTC | Prediction vs reality |
| --- | --- | --- | --- | --- | --- | --- |
| deepseek-v4-pro | Uncertain | N/A | N/A | abstained | 2026-10-22T17:07:58.950855\+00:00 | not\_evaluable |
| deepseek-v4.1-flash | Uncertain | N/A | N/A | abstained | 2026-10-22T17:08:28.869489\+00:00 | not\_evaluable |
| glm-5.2 | Failure | N/A | N/A | predicted | 2026-10-22T17:11:49.299449\+00:00 | not\_evaluable |
| kimi-k3 | Uncertain | N/A | N/A | abstained | 2026-10-22T17:08:54.945093\+00:00 | not\_evaluable |

These are actual stored records. Probability and confidence are not clinically calibrated. Refusals and failures remain in the assigned denominator.

## Consensus and actual result

Majority prediction: Uncertain.
Assigned model records: 4.
Actual result: Awaiting results. No correctness score is available.

Public sources:
- SKYGLO frozen registered design: https://clinicaltrials.gov/api/v2/studies/NCT06047080
- Indirect relapsed DLBCL STARGLO prior: https://www.roche.com/investors/updates/inv-update-2025-12-08
