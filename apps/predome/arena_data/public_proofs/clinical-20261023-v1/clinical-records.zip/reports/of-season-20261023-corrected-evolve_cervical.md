# eVOLVE-Cervical

Current formal clinical question.

[Open this exact record](https://8.148.145.28/arena?target=of-season-20261023-corrected-evolve_cervical)

## Clinical trial

| Field | Recorded value |
| --- | --- |
| NCT | NCT06079671 |
| Drug | volrustomig |
| Sponsor | AstraZeneca |
| Indication | High-risk locally advanced cervical cancer |
| Phase | PHASE3 |
| Study design | \{"allocation": "RANDOMIZED", "enrollment": \{"count": 800, "type": "ESTIMATED"\}, "intervention\_model": "PARALLEL", "masking": "QUADRUPLE", "primary\_purpose": "TREATMENT"\} |
| Trial status | RECRUITING |
| Primary endpoint | Progression-free Survival \(PFS\) based on the investigator assessment in all randomized participants \(FAS\) |
| Population | Females age &gt;=15, FIGO 2018 stage IIIA-IVA cervical cancer without distant metastasis, no progression after platinum concurrent chemoradiotherapy; all randomized full analysis set \(FAS\), not an older PD-L1-high subgroup definition. |
| Comparison | Volrustomig versus placebo after completion of concurrent chemoradiotherapy. |
| Success definition | The first official decisive prespecified primary analysis of investigator-assessed PFS in all randomized FAS reports statistically qualifying superiority favoring the experimental regimen over the specified comparator in the specified analysis population, under the operative protocol/SAP including any interim and multiplicity rules. Success=1 only when that exact hypothesis qualifies; failure=0 only when an official decisive analysis states that exact primary criterion was not met \(including explicit target-specific futility\). Other populations/endpoints, nominal significance, non-target trial results, approval, silence, delay and commercial discontinuation without decisive endpoint assessment do not resolve the target. If SAP qualification or the exact analysis population remains unclear, outcome remains unresolved. |
| Information cutoff | 2026-10-22T17:00:02.856446\+00:00 |
| Expected readout / archived readout | 2027 sponsor guidance |

## AI Clinical Trial Predictions

| Model / version | Outcome | Success probability | Confidence | Status | Record time UTC | Prediction vs reality |
| --- | --- | --- | --- | --- | --- | --- |
| deepseek-v4-pro | Uncertain | N/A | N/A | abstained | 2026-10-22T17:12:58.457522\+00:00 | not\_evaluable |
| deepseek-v4.1-flash | Uncertain | N/A | N/A | abstained | 2026-10-22T17:12:57.522356\+00:00 | not\_evaluable |
| glm-5.2 | Uncertain | N/A | N/A | failed | 2026-10-22T17:19:56.595049\+00:00 | not\_evaluable |
| kimi-k3 | Uncertain | N/A | N/A | abstained | 2026-10-22T17:13:16.061129\+00:00 | not\_evaluable |

These are actual stored records. Probability and confidence are not clinically calibrated. Refusals and failures remain in the assigned denominator.

## Consensus and actual result

Majority prediction: Uncertain.
Assigned model records: 4.
Actual result: Awaiting results. No correctness score is available.

Public sources:
- eVOLVE-Cervical frozen registered design: https://clinicaltrials.gov/api/v2/studies/NCT06079671
- Negative volrustomig phase III lung cancer prior: https://www.astrazeneca.com/media-centre/press-releases/2026/update-on-evolve-lung02-phase-iii-trial.html
