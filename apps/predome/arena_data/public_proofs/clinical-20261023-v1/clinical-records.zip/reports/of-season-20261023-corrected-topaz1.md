# TOPAZ-1

Current formal clinical question.

[Open this exact record](https://8.148.145.28/arena?target=of-season-20261023-corrected-topaz1)

## Clinical trial

| Field | Recorded value |
| --- | --- |
| NCT | NCT04895241 |
| Drug | litifilimab |
| Sponsor | Biogen |
| Indication | Systemic lupus erythematosus |
| Phase | PHASE3 |
| Study design | \{"allocation": "RANDOMIZED", "enrollment": \{"count": 548, "type": "ACTUAL"\}, "intervention\_model": "PARALLEL", "masking": "QUADRUPLE", "primary\_purpose": "TREATMENT"\} |
| Trial status | ACTIVE\_NOT\_RECRUITING |
| Primary endpoint | Percentage of Participants Who Achieved a Systemic Lupus Erythematosus Responder Index of 4 \(SRI-4\) Response at Week 52 |
| Population | Active SLE meeting 2019 EULAR/ACR criteria on stable nonbiologic standard care; target high-dose versus placebo groups of randomized TOPAZ-1, excluding TOPAZ-2 and unrelated durvalumab biliary TOPAZ-1. |
| Comparison | High-dose litifilimab \+ nonbiologic standard care versus placebo \+ same standard care; low-dose comparison is not this target. |
| Success definition | The first official decisive prespecified primary analysis of Week-52 SRI-4 responder proportion, high-dose litifilimab versus placebo reports statistically qualifying superiority favoring the experimental regimen over the specified comparator in the specified analysis population, under the operative protocol/SAP including any interim and multiplicity rules. Success=1 only when that exact hypothesis qualifies; failure=0 only when an official decisive analysis states that exact primary criterion was not met \(including explicit target-specific futility\). Other populations/endpoints, nominal significance, non-target trial results, approval, silence, delay and commercial discontinuation without decisive endpoint assessment do not resolve the target. If SAP qualification or the exact analysis population remains unclear, outcome remains unresolved. |
| Information cutoff | 2026-10-22T17:00:02.856446\+00:00 |
| Expected readout / archived readout | 2026 sponsor guidance |

## AI Clinical Trial Predictions

| Model / version | Outcome | Success probability | Confidence | Status | Record time UTC | Prediction vs reality |
| --- | --- | --- | --- | --- | --- | --- |
| deepseek-v4-pro | Uncertain | N/A | N/A | abstained | 2026-10-22T17:10:37.630284\+00:00 | not\_evaluable |
| deepseek-v4.1-flash | Uncertain | N/A | N/A | abstained | 2026-10-22T17:10:32.791482\+00:00 | not\_evaluable |
| glm-5.2 | Uncertain | N/A | N/A | failed | 2026-10-22T17:14:39.784999\+00:00 | not\_evaluable |
| kimi-k3 | Uncertain | N/A | N/A | abstained | 2026-10-22T17:11:05.624355\+00:00 | not\_evaluable |

These are actual stored records. Probability and confidence are not clinically calibrated. Refusals and failures remain in the assigned denominator.

## Consensus and actual result

Majority prediction: Uncertain.
Assigned model records: 4.
Actual result: Awaiting results. No correctness score is available.

Public sources:
- TOPAZ-1 frozen registered design: https://clinicaltrials.gov/api/v2/studies/NCT04895241
- LILAC phase II SLE prior: https://investors.biogen.com/news-releases/news-release-details/new-england-journal-medicine-publishes-second-manuscript
