# Predome Open Forecast — public launch bundle

One Trial. Multiple Models. One Clear Comparison.

This is an export of actual public clinical records from https://8.148.145.28/arena.
Each records/ file preserves the public API object; each reports/ file is a readable clinical summary of that same object.
Use the exact page URLs in manifest.json when sharing. Model versions, record times, official result links and missing responses remain visible.
Success probability and confidence are N/A because clinical calibration is not established.
Historical replays are separate from current formal predictions and do not earn prospective hits.
The snapshot creation time is an export time, not a model prediction time or an independent timestamp proof.
SHA-256 entries verify the ZIP's files; they do not prove clinical validity or third-party timestamp attestation.
This bundle does not include private data, prompts, tokens, cost, internal metrics, or admin access.
No marketing messages have been sent and no sales conversion or clinical performance is claimed.
